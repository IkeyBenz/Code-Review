# Code-Review Command Line Interface

## Installation:
    pip3 install codereview

