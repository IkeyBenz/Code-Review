colors = {
  'blue':"\033[94m",
  'green':"\033[92m",
  'norm':"\033[0m",
  'bgWhite':"\033[46m",
  'header':"\033[95m",
  'bold':"\033[1m",
  'yellow':"\033[33;1m"
}